/ 에서 아래의 명령을 실행
sudo chmod -R 755 /usr/share/nginx/html
sudo chmod -R 777 /var/lib/php/session
sudo chown -R vmuser:vmuser /usr/share/nginx/html
sudo chown -R vmuser:vmuser /var/lib/php/session
