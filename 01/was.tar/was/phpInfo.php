<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>PHP Detail Information</title>
<link rel="stylesheet" type="text/css" href="./common.css">
<link rel="shortcut icon" type="image/x-icon" href="./favicon.ico" />
<script type="text/javascript" src="./common.js"></script>
</head>

<body>
<div class="popZone" style="background-color:#000000">■ PHP Detail Information</div>
<div class="wrap">
<br>
<?=phpinfo()?>
</body>
</html>